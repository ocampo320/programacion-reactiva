**Project Description**
Source code and presentation materials from the ALT.NET Seattle Open Space 2011 conference.
